

<?php $__env->startSection('title', 'FoodMatch · Comparar'); ?>

<?php $__env->startSection('content'); ?>
<div class="app pad">
    <a class="meta" href="<?php echo e(route('explorar')); ?>">← Volver</a>
    <div style="font-weight:700;font-size:18px;margin:10px 0 14px">Comparando 3 locales</div>

    <table>
        <tr><th></th><th>Wok</th><th>Sushi</th><th>Noodle</th></tr>
        <tr><td>Precio</td><td class="best ok">$8.500</td><td>$9.200</td><td class="warn">$12.900</td></tr>
        <tr><td>Distancia</td><td class="best">280m</td><td>600m</td><td>1,1km</td></tr>
        <tr><td>Promo</td><td>Menú</td><td class="best">2x1</td><td>—</td></tr>
        <tr><td>Presupuesto</td><td class="best ok">✔</td><td class="ok">✔</td><td class="warn">+$2.900</td></tr>
    </table>

    <div class="reco">
        <b>⭐ Mejor para ti:</b> Wok Central<br>
        <span class="meta">Más barato y más cerca, dentro de tu presupuesto.</span>
    </div>

    <a class="btn" href="<?php echo e(route('ficha')); ?>">Ver ficha de Wok Central</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\foodmatch\resources\views/comparar.blade.php ENDPATH**/ ?>