<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'FoodMatch'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/foodmatch.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH D:\laragon\www\foodmatch\resources\views/layouts/app.blade.php ENDPATH**/ ?>