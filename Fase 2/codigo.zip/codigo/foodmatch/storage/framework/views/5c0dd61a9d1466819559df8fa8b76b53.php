

<?php $__env->startSection('title', 'FoodMatch · Entrar'); ?>

<?php $__env->startSection('content'); ?>
<div class="app pad" style="display:flex;flex-direction:column;justify-content:center;min-height:100vh">
    <div class="rainbow"></div>
    <div class="logo">Food<span>Match</span></div>
    <div class="meta" style="margin:4px 0 18px">Qué comer, dónde y si te alcanza</div>
    <input class="field" placeholder="Correo">
    <input class="field" type="password" placeholder="Contraseña">
    <a class="btn" href="<?php echo e(route('explorar')); ?>">Entrar</a>
    <div class="meta" style="text-align:center;margin-top:14px">Crear cuenta</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\foodmatch\resources\views/login.blade.php ENDPATH**/ ?>