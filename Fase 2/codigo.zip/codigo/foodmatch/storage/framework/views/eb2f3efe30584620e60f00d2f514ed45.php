

<?php $__env->startSection('title', 'FoodMatch · Explorar'); ?>

<?php $__env->startSection('content'); ?>
<div class="app" style="height:100vh">
    <div class="map">
        <div class="me" style="top:38%;left:46%"></div>
        <div class="pin c-asian" style="top:30%;left:20%"></div>
        <div class="pin c-sushi" style="top:44%;left:70%"></div>
        <div class="pin c-pizza" style="top:50%;left:24%"></div>
        <div class="pin c-burger" style="top:26%;left:72%;opacity:.35"></div>
    </div>

    <div class="searchbar">
        <span>¿Qué se te antoja?</span>
        <a href="<?php echo e(route('filtros')); ?>"><b>Filtros ⚙</b></a>
    </div>
    <div class="chips">
        <span class="chip o">📍 Cerca</span>
        <span class="chip o">🔥 Con oferta</span>
    </div>

    <div class="sheet">
        <div class="grab"></div>
        <div style="font-size:14px;font-weight:700">Ofertas cerca de ti
            <span class="meta" style="float:right">Lista ⇄ Mapa</span>
        </div>
        <a class="rowi" href="<?php echo e(route('ficha')); ?>"><span class="dot c-sushi"></span><b>Sushi Express</b><span class="meta">2x1 · 600m</span><span class="ok push">$9.200</span></a>
        <a class="rowi" href="<?php echo e(route('ficha')); ?>"><span class="dot c-pizza"></span><b>Pizzería Roma</b><span class="meta">-30% · 900m</span><span class="ok push">$8.900</span></a>
        <a class="rowi" href="<?php echo e(route('ficha')); ?>"><span class="dot c-asian"></span><b>Wok Central</b><span class="meta">Menú · 280m</span><span class="ok push">$8.500</span></a>
        <a class="btn ghost" style="margin-top:8px;padding:9px" href="<?php echo e(route('comparar')); ?>">Comparar locales</a>
    </div>

    <div class="tab">
        <a class="on" href="<?php echo e(route('explorar')); ?>">Explorar</a>
        <span>Favoritos</span>
        <span>Perfil</span>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\foodmatch\resources\views/explorar.blade.php ENDPATH**/ ?>