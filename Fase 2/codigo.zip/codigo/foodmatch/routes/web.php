<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'login')->name('login');
Route::view('/explorar', 'explorar')->name('explorar');
Route::view('/filtros', 'filtros')->name('filtros');
Route::view('/comparar', 'comparar')->name('comparar');
Route::view('/ficha', 'ficha')->name('ficha');
