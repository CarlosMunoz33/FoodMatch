<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'FoodMatch')</title>
    <link rel="stylesheet" href="{{ asset('css/foodmatch.css') }}">
</head>
<body>
    @yield('content')
</body>
</html>