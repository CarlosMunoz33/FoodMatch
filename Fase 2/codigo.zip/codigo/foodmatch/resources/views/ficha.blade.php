@extends('layouts.app')

@section('title', 'FoodMatch · Wok Central')

@section('content')
<div class="app" style="padding-bottom:70px">
    <div class="hero"></div>
    <div class="promo">🔥 Hoy: menú del día $8.500 hasta las 16:00</div>

    <div style="padding:16px">
        <div style="font-weight:800;font-size:22px">Wok Central</div>
        <div class="meta">Asiática · 280m · abierto hasta 22:00</div>

        <div class="rowi" style="margin-top:12px"><span>Arroz frito + bebida</span><span class="ok push">$8.500</span></div>
        <div class="rowi"><span>Pad thai</span><span class="ok push">$9.800</span></div>
        <div class="rowi"><span>Rollitos primavera</span><span class="ok push">$4.200</span></div>

        <div style="display:flex;gap:10px">
            <a class="btn" style="flex:1" href="#">Cómo llegar</a>
            <a class="btn ghost" style="flex:1" href="#">♡ Guardar</a>
        </div>
        <a class="meta" style="display:block;text-align:center;margin-top:16px" href="{{ route('explorar') }}">← Volver a Explorar</a>
    </div>

    <div class="tab">
        <a href="{{ route('explorar') }}">Explorar</a>
        <span>Favoritos</span>
        <span>Perfil</span>
    </div>
</div>
@endsection