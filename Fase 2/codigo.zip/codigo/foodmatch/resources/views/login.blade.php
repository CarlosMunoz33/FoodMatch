@extends('layouts.app')

@section('title', 'FoodMatch · Entrar')

@section('content')
<div class="app pad" style="display:flex;flex-direction:column;justify-content:center;min-height:100vh">
    <div class="rainbow"></div>
    <div class="logo">Food<span>Match</span></div>
    <div class="meta" style="margin:4px 0 18px">Qué comer, dónde y si te alcanza</div>
    <input class="field" placeholder="Correo">
    <input class="field" type="password" placeholder="Contraseña">
    <a class="btn" href="{{ route('explorar') }}">Entrar</a>
    <div class="meta" style="text-align:center;margin-top:14px">Crear cuenta</div>
</div>
@endsection