@extends('layouts.app')

@section('title', 'FoodMatch · Filtros')

@section('content')
<div class="app pad">
    <div class="grab"></div>
    <div style="font-weight:700;font-size:18px;margin-bottom:16px">Filtrar</div>

    <div class="meta">Presupuesto · <b style="color:var(--ink)">hasta $10.000</b></div>
    <div class="bar"><i style="width:55%"></i></div>

    <div class="meta">Distancia · <b style="color:var(--ink)">2 km</b></div>
    <div class="bar"><i style="width:30%"></i></div>

    <div class="meta" style="margin-bottom:8px">Tipo de comida</div>
    <span class="chip c-asian">Asiática</span>
    <span class="chip c-pizza">Pizza</span>
    <span class="chip c-sushi">Sushi</span>
    <span class="chip c-burger">Burger</span>
    <span class="chip c-vegan">Vegano</span>

    <div class="rowi" style="margin-top:12px"><span>Solo con oferta hoy</span><b class="push">● Sí</b></div>
    <div class="rowi"><span>Mostrar ofertas de otras zonas</span><b class="push meta">○ No</b></div>

    <a class="btn" href="{{ route('explorar') }}">Ver 12 resultados</a>
</div>
@endsection