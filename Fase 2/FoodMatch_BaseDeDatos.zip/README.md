# Base de datos básica — FoodMatch

Esto cubre el modelo de datos mínimo para las 8 historias de usuario del PMV:
registro/login, preferencias y presupuesto, ubicación, búsqueda/recomendación,
comparación, evaluación y administración de restaurantes.

## Qué incluye

```
database/migrations/
  2026_10_04_100000_add_preferences_to_users_table.php   -> agrega campos a la tabla users
  2026_10_04_100100_create_restaurantes_table.php        -> tabla restaurantes
  2026_10_04_100200_create_evaluaciones_table.php        -> tabla evaluaciones

database/seeders/
  FoodMatchSeeder.php   -> datos de ejemplo (incluye Bonapetit)

app/Models/
  User.php          -> OJO: Laravel ya trae este archivo. No lo reemplaces completo,
                       solo copia los $fillable/$casts/relaciones dentro de tu User.php
  Restaurante.php    -> se puede copiar tal cual
  Evaluacion.php     -> se puede copiar tal cual

diagrama_er_foodmatch.png -> diagrama visual de las 3 tablas y sus relaciones
```

## Cómo instalarlo en tu proyecto Laragon/Laravel

1. Copia las 3 carpetas (`database/migrations`, `database/seeders`, `app/Models`)
   dentro de la carpeta de tu proyecto Laravel, reemplazando solo
   `Restaurante.php` y `Evaluacion.php` (son nuevos). Para `User.php`, copia
   manualmente los campos nuevos dentro de tu archivo existente.

2. Corre las migraciones:
   ```
   php artisan migrate
   ```

3. (Opcional) Carga los datos de ejemplo:
   ```
   php artisan db:seed --class=FoodMatchSeeder
   ```

## Qué quedó afuera (a propósito, por ahora)

- Sistema de puntos / niveles (digievolución futura, no es parte del PMV).
- Visitas verificadas.
- Tabla de "zonas" o categorías normalizadas — por ahora `tipo_comida` es
  texto libre, simple para el PMV. Si más adelante quieren una lista cerrada
  de categorías, se puede separar en su propia tabla `categorias`.

## Próximo paso sugerido

Con esto ya pueden construir los controladores (`UsuarioController`,
`RestauranteController`, `EvaluacionController`) que vimos en la tabla de
tareas del Sprint Backlog. Si quieres, en la próxima conversación armamos
esos controladores y las rutas también.
