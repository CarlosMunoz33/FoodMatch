<?php

namespace App\Models;

// Nota: Laravel ya trae este archivo por defecto (con Authenticatable, Notifiable, etc).
// No lo reemplaces completo: solo copia los $fillable, $casts y las relaciones de abajo
// dentro de tu User.php existente.

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        // Campos de preferencias (FM-HU-003 y FM-HU-004):
        'tipo_comida_preferida',
        'presupuesto_habitual',
        'zona_busqueda',
        'ultima_latitud',
        'ultima_longitud',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'ultima_latitud' => 'decimal:7',
        'ultima_longitud' => 'decimal:7',
    ];

    /**
     * Evaluaciones que este usuario ha dejado en restaurantes (FM-HU-007).
     */
    public function evaluaciones(): HasMany
    {
        return $this->hasMany(Evaluacion::class);
    }

    /**
     * Restaurantes que este usuario administra, si es dueño de un local
     * verificado como Bonapetit (FM-HU-008).
     */
    public function restaurantesAdministrados(): HasMany
    {
        return $this->hasMany(Restaurante::class, 'administrador_id');
    }
}
