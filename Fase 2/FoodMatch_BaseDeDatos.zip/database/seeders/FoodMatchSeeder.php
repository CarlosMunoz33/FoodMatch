<?php

namespace Database\Seeders;

use App\Models\Evaluacion;
use App\Models\Restaurante;
use App\Models\User;
use Illuminate\Database\Seeder;

class FoodMatchSeeder extends Seeder
{
    /**
     * Carga datos de ejemplo para probar el flujo completo de FoodMatch.
     * Ejecutar con: php artisan db:seed --class=FoodMatchSeeder
     */
    public function run(): void
    {
        $usuario = User::create([
            'name' => 'Usuario de Prueba',
            'email' => 'usuario@foodmatch.test',
            'password' => bcrypt('password'),
            'tipo_comida_preferida' => 'Completos y hamburguesas',
            'presupuesto_habitual' => 7000,
            'zona_busqueda' => 'Santiago Centro',
        ]);

        $adminBonapetit = User::create([
            'name' => 'Administrador Bonapetit',
            'email' => 'bonapetit@foodmatch.test',
            'password' => bcrypt('password'),
        ]);

        $bonapetit = Restaurante::create([
            'administrador_id' => $adminBonapetit->id,
            'nombre' => 'Bonapetit',
            'tipo_comida' => 'Completos y hamburguesas',
            'precio_promedio' => 5500,
            'direccion' => 'Av. Siempre Viva 123, Santiago',
            'latitud' => -33.4489,
            'longitud' => -70.6693,
            'verificado' => true,
            'horario' => 'Lun a Dom 11:00 - 23:00',
        ]);

        $completosElRey = Restaurante::create([
            'nombre' => 'Completos El Rey',
            'tipo_comida' => 'Completos',
            'precio_promedio' => 4200,
            'latitud' => -33.4500,
            'longitud' => -70.6650,
            'verificado' => false,
        ]);

        Evaluacion::create([
            'user_id' => $usuario->id,
            'restaurante_id' => $bonapetit->id,
            'puntuacion' => 5,
            'comentario' => 'Buen completo por el precio.',
        ]);
    }
}
