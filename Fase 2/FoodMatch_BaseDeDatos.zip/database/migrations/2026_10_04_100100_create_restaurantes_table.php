<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Tabla restaurantes: cubre las historias FM-HU-005 (recomendaciones),
     * FM-HU-006 (comparación) y FM-HU-008 (administración de restaurantes).
     */
    public function up(): void
    {
        Schema::create('restaurantes', function (Blueprint $table) {
            $table->id();

            // Dueño/administrador del local verificado (ej. Bonapetit). Null = aún no reclamado.
            $table->foreignId('administrador_id')->nullable()
                ->constrained('users')->nullOnDelete();

            $table->string('nombre');
            $table->string('tipo_comida');           // ej: "Completos y hamburguesas"
            $table->unsignedInteger('precio_promedio'); // en pesos, para filtrar por presupuesto
            $table->string('direccion')->nullable();
            $table->decimal('latitud', 10, 7);
            $table->decimal('longitud', 10, 7);
            $table->boolean('verificado')->default(false); // ej: Bonapetit = true
            $table->string('horario')->nullable();
            $table->string('telefono_contacto')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('restaurantes');
    }
};
